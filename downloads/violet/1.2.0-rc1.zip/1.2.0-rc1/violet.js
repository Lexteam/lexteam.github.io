function navBarOpen() {
    $('#nav-bar').show();
}

function navBarClose() {
    $('#nav-bar').hide();
}
