$(document).ready(function ($) {

    $('#navbar-menu').on('click', function () {
        $('#nav-bar').toggle();
    });

});
